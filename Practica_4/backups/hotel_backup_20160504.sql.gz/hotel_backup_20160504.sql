-- sqldump-php SQL Dump
-- https://github.com/clouddueling/mysqldump-php
--
-- Host: 127.0.0.1
-- Generation Time: Wed, 04 May 2016 23:09:35 +0200

--
-- Database: `sibw`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;

CREATE TABLE `bookings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_roomtype` int(11) DEFAULT NULL,
  `id_room` int(11) DEFAULT NULL COMMENT 'es el admin quien asigna la habitacion',
  `id_user` datetime DEFAULT NULL,
  `date_booking` datetime DEFAULT NULL,
  `date_in` datetime DEFAULT NULL,
  `date_out` datetime DEFAULT NULL,
  `comments` text COLLATE utf8_spanish_ci,
  `state` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `bookings`
--

-- --------------------------------------------------------

--
-- Table structure for table `cms`
--

DROP TABLE IF EXISTS `cms`;

CREATE TABLE `cms` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `cms`
--

INSERT INTO `cms` VALUES ('1','HOME'),('2','ROOMS'),('3','SERVICES'),('4','HOME_DESCRIPTION'),('142','TOGGLE_NAVIGATION'),('143','WELCOME'),('144','VIEW_PROFILE'),('145','VIEW_BOOKINGS'),('146','CLOSE_SESSION'),('147','BOOKING'),('148','GALLERY'),('149','LOCATION'),('150','CONTACT'),('151','CONTACT_DETAILS'),('153','SEND_US_A_MESSAGE'),('154','FULL_NAME'),('155','PHONE'),('156','EMAIL'),('157','MESSAGE'),('158','SEND'),('159','ROOM'),('160','PRICE'),('161','OTHER_ROOMS'),('162','BACKUP'),('163','PROFILE'),('164','SERVICE'),('165','OTHER_SERVICES'),('166','EDIT'),('167','LOGIN'),('169','EDIT_TRANSLATIONS'),('170','CREDITS'),('171','EDIT_ROOM'),('172','NIGHT'),('173','EDIT_SERVICE'),('174','DAY'),('175','SIGN_IN_TO_CONTINUE_TO'),('176','PASSWORD'),('177','SIGN_IN'),('178','REMEMBER_ME');
-- --------------------------------------------------------

--
-- Table structure for table `cms_lang`
--

DROP TABLE IF EXISTS `cms_lang`;

CREATE TABLE `cms_lang` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_lang` int(11) DEFAULT NULL,
  `value` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `cms_lang`
--

INSERT INTO `cms_lang` VALUES ('1','1','Inicio'),('2','1','Habitaciones'),('3','1','Servicios'),('4','1','<p>El Hotel Plaza Nueva está situado en el pleno centro monumental, comercial y administrativo de Granada, a 10 minutos de la Alhambra.</p>\r\n<p>El hotel ofrece una amplia y eficiente gama de servicios extra que satisfarán cualquier necesidad que le surja, reservas a shows de flamenco o visitas turísticas por la ciudad y la Alhambra.</p>\r\n<p>El hotel le ofrece 25 amplias y luminosas habitaciones repartidas sobre 3 plantas con ascensor.</p>\r\n<p>Cada planta del hotel y cada habitación poseen un nombre y encanto propio. Este nombre es una representación de un evento importante en la vida e historia de Granada. No tienen tarjetas magnéticas para abrir las puertas de las habitaciones, preferimos la originalidad que proporciona una tradicional llave.</p>\r\n<p>El hotel ofrece el servicio de desayuno continental en la cafetería, donde podrá disfrutar de conexión WIFI. Asimismo podrá obtener mediante pago del servicio conexión WIFI en su habitación.</p>\r\n<p>Confiamos en que disfrute plenamente su estancia entre nosotros así como de nuestra bella ciudad.</p>\r\n<p>Número de registro del hotel en la consejería de turismo de Andalucía: H/GR/01181</p>'),('142','1','Desplegar'),('143','1','Bienvenido'),('144','1','Ver perfil'),('145','1','Ver reservas'),('146','1','Cerrar sesión'),('147','1','Reservar'),('148','1','Galería'),('149','1','Ubicación'),('150','1','Contacte'),('151','1','Detalles de contacto'),('153','1','Envianos un mensaje'),('154','1','Nombre completo'),('155','1','Teléfono'),('156','1','E-Mail'),('157','1','Mensaje'),('158','1','Enviar'),('159','1','Habitación'),('160','1','Precio'),('161','1','Otras habitaciones'),('162','1','Backup'),('163','1','Mi perfil'),('164','1','Servicio'),('165','1','Otros servicios'),('166','1','Editar'),('167','1','Iniciar sesión'),('169','1','Editar traducciones'),('170','1','Creditos'),('171','1','Editar habitación'),('172','1','Noche'),('173','1','Editar servicio'),('174','1','Dia'),('175','1','Inicie sesión para continuar en'),('176','1','Contraseña'),('177','1','Iniciar sesión'),('178','1','Recordarme');
-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;

CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(2) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` VALUES ('1','es'),('2','en'),('3','fr'),('4','it'),('5','de');
-- --------------------------------------------------------

--
-- Table structure for table `phisicalrooms`
--

DROP TABLE IF EXISTS `phisicalrooms`;

CREATE TABLE `phisicalrooms` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_room` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `phisicalrooms`
--

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;

CREATE TABLE `rooms` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `price` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` VALUES ('1','38'),('2','56'),('3','86'),('4','2');
-- --------------------------------------------------------

--
-- Table structure for table `rooms_lang`
--

DROP TABLE IF EXISTS `rooms_lang`;

CREATE TABLE `rooms_lang` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_lang` int(11) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `description` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `rooms_lang`
--

INSERT INTO `rooms_lang` VALUES ('1','1','Habitación doble o twin (2 camas)','En nuestras habitaciones standard disfrutará de todo el equipamiento y comodidades que su estancia en Granada merece.'),('2','1','Habitación doble superior','Disfrute de una magnifica vista de Plaza Nueva y el centro de Granada desde nuestras habitaciones superiores.'),('3','1','Habitacion triple','En nuestras habitaciones triples podrá disfrutar de sus vacaciones en familia o con amigos en el centro de Granada.'),('4','1','Habitación Baratera','Esta es una habitación muy cutre, para probar si esto ba, encima es carísima.');
-- --------------------------------------------------------

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;

CREATE TABLE `services` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `price` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` VALUES ('1','46'),('2','26'),('3','1');
-- --------------------------------------------------------

--
-- Table structure for table `services_lang`
--

DROP TABLE IF EXISTS `services_lang`;

CREATE TABLE `services_lang` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_lang` int(11) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `description` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `services_lang`
--

INSERT INTO `services_lang` VALUES ('1','1','Visita a la Alhambra','Descubrirá con nostros la única Ciudad Medieval Musulmana bien conservada del mundo, la Alhambra; visitando sus palacios, Mexuar, Comares, Leones, Generalife; paseando por sus patios, de los Leones, de los Arrayenes, la Reja, la Acequia, la Sultana; y disfrutando de sus jardines, de Partal, de la Medina y por suspuesto del Generalife con sus gracioso juegos de agua, y su laberíntico diseño.'),('2','1','Viaje a Sierra Nevada','Podrá disfrutar de paseos por los senderos del parque natural de Sierra Nevada en temporada de verano o de un día de esquí con alquiler de equipo, profesor privado y forfait por un día en temporada de invierno.'),('3','1','Viaje a Albolote','Visita a la carcel de albolote, por solo 1 euro!. con entrada a la celda');
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(45) CHARACTER SET utf8 NOT NULL,
  `password` varchar(45) NOT NULL,
  `role` tinyint(1) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `date_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `firstname` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `lastname` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `phone` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `id_language` (`id_lang`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES ('1','admin@ernesto.es','c93ccd78b2076528346216b3b2f701e6','1','1','2014-04-30 22:00:00','Administrador','',''),('2','user@ernesto.es','b5b73fae0d87d8b4e2573105f8fbe7bc','0','1','2014-04-30 22:00:00','User','','');
